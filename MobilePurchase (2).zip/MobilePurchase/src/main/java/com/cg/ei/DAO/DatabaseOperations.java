package com.cg.ei.DAO;

import java.util.*;

import com.cg.ei.bean.Customer;
import com.cg.ei.bean.Mobile;
import com.cg.ei.bean.Order;

public class DatabaseOperations implements OrderDAO {

	
	
	public void purchasemobile(Customer c, Order o) {
		// TODO Auto-generated method stub
		
		orders.put(o.getOrder_Id(), o);
		customers.put(c.getCustId(), c);

		System.out.println("Purches Successfully Completed:\nName\tOrder Id\tModel\tPrice\n=========================================");
		System.out.print(c.getCustName()+"\t"+o.getOrder_Id());
	}

	public void addMobiles(Mobile m) {
		// TODO Auto-generated method stub
		mobiles.put(m.getModel(),m);
	}

	public Order getpurchasedetails(int custId) {
			//for()
		return null;
	}

	public Map<String, Mobile> displayAvailableMobiles() {
		// TODO Auto-generated method stub
		
		//Map<String, Integer> sorted = budget.entrySet().stream().sorted(comparingByValue()).collect(toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2,LinkedHashMap::new));
		
		return mobiles;
	}

	public Map<Integer, Customer> customerDetails() {
		// TODO Auto-generated method stub
		
		
		return customers;
	}

	public Map<Integer, Order> orderDetails(int custId) {
		Map<Integer,Order> custOrd=new HashMap<Integer,Order>();
		for(Order obj:orders.values()) {
			if(custId==obj.getCustId())
			custOrd.put(obj.getOrder_Id(),obj);
		}
		return custOrd;
	}

	public Customer getCustomer(int custId) {



		return null;
	}

	public Order getOrder(int orderId, int custId) {
		// TODO Auto-generated method stub
		
		
		return null;
	}

	public Mobile getMobile(String model) {

		Mobile m=null;
		for(String s:mobiles.keySet()) {
			if(s.equals(model)) {
				m=mobiles.get(s);
				int i=m.getInStore()-1;
				m.setInStore(i);
			}
		}
		return m;
	}

	
}
