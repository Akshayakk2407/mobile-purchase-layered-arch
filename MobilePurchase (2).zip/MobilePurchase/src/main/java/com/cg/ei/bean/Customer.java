package com.cg.ei.bean;

public class Customer {
	
	private int custId;
	private String custName;
	private String address;
	private String cellno;
	
	public int getCustId() {
		return custId;
	}
	
	public void setCustId(int custId) {
		this.custId = custId;
	}
	
	public String getCustName() {
		return custName;
	}
	
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getCellno() {
		return cellno;
	}
	
	public void setCellno(String cellno) {
		this.cellno = cellno;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", address=" + address + ", cellno=" + cellno
				+ "]";
	}

	public Customer(int custId, String custName, String address, String cellno) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.address = address;
		this.cellno = cellno;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
