package com.cg.ei.bean;

import java.util.Comparator;

public class Mobile implements Comparator {

	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}

	private String model;
	private int totalprice_GST;
	private int inStore;
	
	
	
	public Mobile(String model, int totalprice_GST, int inStore) {
		super();
		this.model = model;
		this.totalprice_GST = totalprice_GST;
		this.inStore = inStore;
	}

	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	public int getTotalprice_GST() {
		return totalprice_GST;
	}
	
	public void setTotalprice_GST(int totalprice_GST) {
		this.totalprice_GST = totalprice_GST;
	}
	
	public int getInStore() {
		return inStore;
	}
	
	public void setInStore(int inStore) {
		this.inStore = inStore;
	}

	@Override
	public String toString() {
		return "\t" + model + "\t\t" + totalprice_GST + "\t" + inStore+"\n";
	}

	public int compare(Mobile o1, Mobile o2) {
		/*if(o1.getModel().equals(o2.getModel())){
			return 0;
		}
		if(o1.getModel()>o2.getModel())
			return 1;
		else
			return -1;*/
		
		
		
		
		return 0;
	}

	public int compare(Object arg0, Object arg1) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	/*public Mobile compareTo(Mobile m1,Mobile m2) {
		
		
			if(m1.equals(m2))
				
		return m1;
			else
				return m2;
		
	}*/
	
	
	
	
	
	
}
