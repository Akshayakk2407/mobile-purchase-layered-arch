package com.cg.ei.bean;

import java.time.LocalDate;

public class Order {
	
	private String model;
	private int order_Id;
	private int custId;
	private LocalDate date;
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getOrder_Id() {
		return order_Id;
	}
	public void setOrder_Id(int order_Id) {
		this.order_Id = order_Id;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Order [model=" + model + ", order_Id=" + order_Id + ", custId=" + custId + ", date=" + date + "]";
	}
	
	
	
}
