package com.cg.ei.service;

import java.util.*;

import com.cg.ei.bean.*;

public interface OrderService {

	
	
	void purchasemobile(Customer c, String model);
	void addMobiles();
	Order getpurchasedetails(int custId);
	void displayAvailableMobiles();
	Map<Integer,Customer> customerDetails();
	Map<Integer,Order> orderDetails(int custId);
	
	boolean getMobile(String model);
	
	void addMobile(Mobile m);
}
