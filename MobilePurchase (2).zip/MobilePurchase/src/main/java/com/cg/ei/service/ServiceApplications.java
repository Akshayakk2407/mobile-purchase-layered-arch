package com.cg.ei.service;

import java.time.LocalDate;
import java.util.*;

import com.cg.ei.DAO.*;
import com.cg.ei.bean.Customer;
import com.cg.ei.bean.Mobile;
import com.cg.ei.bean.Order;

public class ServiceApplications implements OrderService {

	DatabaseOperations dao=new DatabaseOperations();
	static int oid=0;
	
	public void purchasemobile(Customer c, String model) {
		
		Order ord=new Order();
		// TODO Auto-generated method stub
		Mobile m=dao.getMobile(model);
		if(m!=null) {
			oid++;
			ord.setOrder_Id(oid);
			ord.setCustId(c.getCustId());
			ord.setDate(LocalDate.now());
			ord.setModel(model);
			dao.purchasemobile(c, ord);
			System.out.println("\t"+model+"\t"+m.getTotalprice_GST()+"\n");
		}
	}

	public void addMobiles() {
		// TODO Auto-generated method stub
		Mobile m=new Mobile("Galaxy S10 Plus",91900,4);
		dao.addMobiles(m);
		m=new Mobile("Galaxy M30",14900,4);
		dao.addMobiles(m);
		m=new Mobile("Oppo F11",15999,4);
		dao.addMobiles(m);
		m=new Mobile("Nokia 6.1 Plus",15380,4);
		dao.addMobiles(m);
		m=new Mobile("Redmi 6 Pro",7900,4);
		dao.addMobiles(m);
		m=new Mobile("Realme 3",10900,4);
		dao.addMobiles(m);
		m=new Mobile("Redmi note 7",12000,4);
		dao.addMobiles(m);
		
	}

	public Order getpurchasedetails(int custId) {
		// TODO Auto-generated method stub
		
		
		return null;
	}

	public void displayAvailableMobiles() {
		Map<String, Mobile>mobiles=new HashMap<String, Mobile>();
		
		mobiles.putAll(dao.displayAvailableMobiles());
		
		for(Mobile m:mobiles.values()) {
			
			System.out.println(m);
		}

	}
	
	
	public Map<String,Mobile> dispMob(){
		return dao.displayAvailableMobiles();
	}

	public Map<Integer, Customer> customerDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<Integer, Order> orderDetails(int custId) {
		// TODO Auto-generated method stub
			
		
		return dao.orderDetails(custId);
	}

	public boolean getMobile(String model) {
		// TODO Auto-generated method stub
		Mobile m=dao.getMobile(model);
		if((m!=null))
			return true;
		else		
			return false;
	}

	public void addMobile(Mobile m) {
		// TODO Auto-generated method stub
		dao.addMobiles(m);
	}

	


}
