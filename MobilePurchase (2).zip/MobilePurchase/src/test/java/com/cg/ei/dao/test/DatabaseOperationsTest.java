package com.cg.ei.dao.test;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.cg.ei.DAO.*;
import com.cg.ei.bean.Customer;
import com.cg.ei.bean.Order;
import com.cg.ei.service.ServiceApplications;

public class DatabaseOperationsTest {

	
	
	ServiceApplications sa=null;
	Customer customer;
	@Before
	public void method() {
	String model="Galaxy M30";
	sa=new ServiceApplications();
	customer=new Customer(1,"Anuja","Pune","8087864923");
	sa.addMobiles();
	 sa.purchasemobile(customer,model);
	}
	
	@Test
	public void testPurchaseNotNull() {
		
		assertNotNull(sa.orderDetails(1));
		
	}
	
	@Test
	public void testPurchaseNull() {
		
		Map<Integer, Order> map=sa.orderDetails(2);
		
		assertNull(map.get(2));
	}
	
	
	@Test
	public void testgetMobileNotNull() {
		
		assertEquals(true,sa.getMobile("Galaxy M30"));
	}
	
	@Test
	public void testgetMobileNull() {
		
		assertEquals(false,sa.getMobile("Galaxy"));
	}
}
